const initialNotes = [
  { id: 'notes-jT-jjsyz61J8XKiI', title: 'Welcome to Notes, Dimas!', body: 'Welcome to Notes! This is your first note. You can archive it, delete it, or create new ones.', createdAt: '2022-07-28T10:03:12.594Z', archived: false },
  { id: 'notes-aB-cdefg12345', title: 'Meeting Agenda', body: 'Discuss project updates and assign tasks for the upcoming week.', createdAt: '2022-08-05T15:30:00.000Z', archived: false },
  { id: 'notes-XyZ-789012345', title: 'Shopping List', body: 'Milk, eggs, bread, fruits, and vegetables.', createdAt: '2022-08-10T08:45:23.120Z', archived: false },
  { id: 'notes-1a-2b3c4d5e6f', title: 'Personal Goals', body: 'Read two books per month, exercise three times a week, learn a new language.', createdAt: '2022-08-15T18:12:55.789Z', archived: false },
  { id: 'notes-LMN-456789', title: 'Recipe: Spaghetti Bolognese', body: 'Ingredients: ground beef, tomatoes, onions, garlic, pasta. Steps:...', createdAt: '2022-08-20T12:30:40.200Z', archived: false },
  { id: 'notes-QwErTyUiOp', title: 'Workout Routine', body: 'Monday: Cardio, Tuesday: Upper body, Wednesday: Rest, Thursday: Lower body, Friday: Cardio.', createdAt: '2022-08-25T09:15:17.890Z', archived: false },
  { id: 'notes-abcdef-987654', title: 'Book Recommendations', body: "1. 'The Alchemist' by Paulo Coelho\n2. '1984' by George Orwell\n3. 'To Kill a Mockingbird' by Harper Lee", createdAt: '2022-09-01T14:20:05.321Z', archived: false },
  { id: 'notes-zyxwv-54321', title: 'Daily Reflections', body: 'Write down three positive things that happened today and one thing to improve tomorrow.', createdAt: '2022-09-07T20:40:30.150Z', archived: false },
  { id: 'notes-poiuyt-987654', title: 'Travel Bucket List', body: '1. Paris, France\n2. Kyoto, Japan\n3. Santorini, Greece\n4. New York City, USA', createdAt: '2022-09-15T11:55:44.678Z', archived: false },
  { id: 'notes-asdfgh-123456', title: 'Coding Projects', body: '1. Build a personal website\n2. Create a mobile app\n3. Contribute to an open-source project', createdAt: '2022-09-20T17:10:12.987Z', archived: false },
  { id: 'notes-5678-abcd-efgh', title: 'Project Deadline', body: 'Complete project tasks by the deadline on October 1st.', createdAt: '2022-09-28T14:00:00.000Z', archived: false },
  { id: 'notes-9876-wxyz-1234', title: 'Health Checkup', body: 'Schedule a routine health checkup with the doctor.', createdAt: '2022-10-05T09:30:45.600Z', archived: false },
  { id: 'notes-qwerty-8765-4321', title: 'Financial Goals', body: '1. Create a monthly budget\n2. Save 20% of income\n3. Invest in a retirement fund.', createdAt: '2022-10-12T12:15:30.890Z', archived: false },
  { id: 'notes-98765-54321-12345', title: 'Holiday Plans', body: 'Research and plan for the upcoming holiday destination.', createdAt: '2022-10-20T16:45:00.000Z', archived: false },
  { id: 'notes-1234-abcd-5678', title: 'Language Learning', body: 'Practice Spanish vocabulary for 30 minutes every day.', createdAt: '2022-10-28T08:00:20.120Z', archived: false },
];

const savedNotes = JSON.parse(localStorage.getItem('ruang-catatan-notes') || 'null');
const savedList = Array.isArray(savedNotes) ? savedNotes : [];
const officialIds = new Set(initialNotes.map((note) => note.id));
let notes = [
  ...initialNotes.map((note) => ({
    ...note,
    archived: savedList.find((savedNote) => savedNote.id === note.id)?.archived ?? note.archived,
  })),
  ...savedList.filter((note) => !officialIds.has(note.id)),
];
let activeFilter = 'active';
let query = '';

const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' })[char]);
const saveNotes = () => localStorage.setItem('ruang-catatan-notes', JSON.stringify(notes));
const formatDate = (date) => new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(date));
const showToast = (message) => {
  const toast = document.querySelector('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2200);
};

class AppHeader extends HTMLElement {
  static get observedAttributes() { return ['app-name', 'owner']; }
  connectedCallback() { this.render(); }
  attributeChangedCallback() { if (this.isConnected) this.render(); }
  render() {
    const name = this.getAttribute('app-name') || 'Notes App';
    const owner = this.getAttribute('owner') || 'Pengguna';
    this.innerHTML = `<style>
      app-header{display:block;position:sticky;top:0;z-index:10;background:rgba(247,244,237,.9);backdrop-filter:blur(12px);border-bottom:1px solid var(--line)}
      app-header nav{width:min(1160px,calc(100% - 40px));height:68px;margin:auto;display:flex;align-items:center;justify-content:space-between}
      app-header .brand{display:flex;align-items:center;gap:10px;font-family:"Fraunces",serif;font-size:1.25rem;font-weight:700}
      app-header .mark{display:grid;width:32px;height:32px;place-items:center;border-radius:50%;background:var(--green);color:#fff}
      app-header .owner{color:var(--muted);font-size:.88rem} @media(max-width:620px){app-header nav{width:calc(100% - 28px)}app-header .owner{display:none}}
    </style><nav aria-label="Navigasi utama"><div class="brand"><span class="mark" aria-hidden="true">✦</span>${escapeHtml(name)}</div><span class="owner">Ruang milik ${escapeHtml(owner)}</span></nav>`;
  }
}

class NoteForm extends HTMLElement {
  connectedCallback() { this.render(); this.setupEvents(); }
  render() {
    const limit = Number(this.getAttribute('max-title')) || 50;
    this.innerHTML = `<style>
      note-form{display:block;padding:28px;border:1px solid var(--line);border-radius:18px;background:var(--paper);box-shadow:var(--shadow)}
      note-form .head{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:22px} note-form h2{font-size:1.55rem}
      note-form .shortcut{color:var(--muted);font-size:.78rem} note-form form{display:grid;grid-template-columns:minmax(0,.8fr) minmax(0,1.5fr) auto;align-items:start;gap:14px}
      note-form label{display:grid;gap:6px;color:var(--muted);font-size:.78rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}
      note-form input,note-form textarea{width:100%;border:1px solid var(--line);border-radius:10px;background:#fff;padding:12px 13px;color:var(--ink);outline:0;resize:vertical}
      note-form textarea{min-height:50px;max-height:180px} note-form input:focus,note-form textarea:focus{border-color:var(--green);box-shadow:0 0 0 3px rgba(49,92,79,.12)}
      note-form .invalid{border-color:#b95142} note-form small{min-height:17px;color:#b95142;font-size:.72rem;text-transform:none;letter-spacing:0}
      note-form .counter{float:right;color:var(--muted)} note-form button{margin-top:21px;padding:12px 20px;border:0;border-radius:10px;background:var(--green);color:#fff;font-weight:700;cursor:pointer;white-space:nowrap}
      note-form button:hover{background:#24483e} note-form button:disabled{opacity:.5;cursor:not-allowed}
      @media(max-width:800px){note-form form{grid-template-columns:1fr}note-form button{margin-top:0}} @media(max-width:620px){note-form{padding:20px}note-form .shortcut{display:none}}
    </style>
    <div class="head"><h2>Catatan baru</h2><span class="shortcut">Ctrl + Enter untuk menyimpan</span></div>
    <form novalidate>
      <label>Judul<input id="title" name="title" type="text" maxlength="${limit}" placeholder="Contoh: Rencana minggu ini" required /><span><small id="title-error"></small><span id="title-count" class="counter">0/${limit}</span></span></label>
      <label>Isi catatan<textarea id="body" name="body" rows="1" placeholder="Tuliskan sesuatu yang ingin kamu ingat..." required></textarea><small id="body-error"></small></label>
      <button type="submit" disabled>Simpan catatan</button>
    </form>`;
  }
  setupEvents() {
    const form = this.querySelector('form');
    const title = this.querySelector('#title');
    const body = this.querySelector('#body');
    const button = this.querySelector('button');
    const validate = () => {
      const titleValue = title.value.trim();
      const bodyValue = body.value.trim();
      const titleError = titleValue.length === 0 ? 'Judul wajib diisi.' : titleValue.length < 3 ? 'Judul minimal 3 karakter.' : '';
      const bodyError = bodyValue.length === 0 ? 'Isi catatan wajib diisi.' : bodyValue.length < 5 ? 'Isi minimal 5 karakter.' : '';
      this.querySelector('#title-error').textContent = titleError;
      this.querySelector('#body-error').textContent = bodyError;
      title.classList.toggle('invalid', Boolean(titleError) && title.value.length > 0);
      body.classList.toggle('invalid', Boolean(bodyError) && body.value.length > 0);
      this.querySelector('#title-count').textContent = `${title.value.length}/${title.maxLength}`;
      button.disabled = Boolean(titleError || bodyError);
      return !button.disabled;
    };
    title.addEventListener('input', validate);
    body.addEventListener('input', () => { body.style.height = 'auto'; body.style.height = `${body.scrollHeight}px`; validate(); });
    form.addEventListener('keydown', (event) => { if (event.ctrlKey && event.key === 'Enter' && validate()) form.requestSubmit(); });
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!validate()) return;
      document.dispatchEvent(new CustomEvent('note:add', { detail: { title: title.value.trim(), body: body.value.trim() } }));
      form.reset(); body.style.height = 'auto'; validate(); title.focus();
    });
  }
}

class NoteItem extends HTMLElement {
  static get observedAttributes() { return ['status']; }
  set note(value) { this._note = value; this.render(); }
  connectedCallback() { this.render(); }
  attributeChangedCallback() { if (this.isConnected) this.render(); }
  render() {
    if (!this._note) return;
    const note = this._note;
    const archived = this.getAttribute('status') === 'archived';
    this.innerHTML = `<style>
      note-item{display:flex;min-width:0} note-item article{position:relative;display:flex;flex:1;min-width:0;min-height:240px;flex-direction:column;padding:24px;border:1px solid var(--line);border-radius:14px;background:var(--paper);transition:transform .2s,box-shadow .2s,border-color .2s}
      note-item article:hover{transform:translateY(-3px);border-color:#b5c3bd;box-shadow:var(--shadow)} note-item .pin{position:absolute;right:20px;top:18px;color:var(--coral);font-size:1.15rem}
      note-item time{color:var(--muted);font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em} note-item h3{margin:14px 28px 10px 0;font-family:"Fraunces",serif;font-size:1.36rem;line-height:1.25}
      note-item .body{display:-webkit-box;margin:0;color:var(--muted);font-size:.94rem;white-space:pre-line;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}
      note-item .actions{display:flex;gap:8px;margin-top:auto;padding-top:20px} note-item button{display:flex;align-items:center;gap:5px;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:transparent;cursor:pointer;font-size:.78rem;font-weight:600}
      note-item button:hover{border-color:var(--green);background:var(--green-soft)} note-item .delete:hover{border-color:#d8a79d;background:#f8e5e0;color:#9d3f32}
    </style><article><span class="pin" aria-hidden="true">✦</span><time datetime="${note.createdAt}">${formatDate(note.createdAt)}</time><h3>${escapeHtml(note.title)}</h3><p class="body">${escapeHtml(note.body)}</p><div class="actions"><button class="archive" type="button">${archived ? '↩ Pulihkan' : '⌑ Arsipkan'}</button><button class="delete" type="button">× Hapus</button></div></article>`;
    this.querySelector('.archive').addEventListener('click', () => document.dispatchEvent(new CustomEvent('note:archive', { detail: { id: note.id } })));
    this.querySelector('.delete').addEventListener('click', () => document.dispatchEvent(new CustomEvent('note:delete', { detail: { id: note.id } })));
  }
}

customElements.define('app-header', AppHeader);
customElements.define('note-form', NoteForm);
customElements.define('note-item', NoteItem);

function renderNotes() {
  const grid = document.querySelector('#notes-grid');
  const filtered = notes.filter((note) => note.archived === (activeFilter === 'archived')).filter((note) => `${note.title} ${note.body}`.toLowerCase().includes(query));
  grid.replaceChildren(...filtered.map((note) => {
    const item = document.createElement('note-item');
    item.setAttribute('status', note.archived ? 'archived' : 'active');
    item.note = note;
    return item;
  }));
  document.querySelector('#empty-state').hidden = filtered.length > 0;
  document.querySelector('#note-count').textContent = `${filtered.length} catatan ${activeFilter === 'archived' ? 'diarsipkan' : 'aktif'}`;
}

document.addEventListener('note:add', ({ detail }) => {
  notes.unshift({ id: `notes-${Date.now()}`, title: detail.title, body: detail.body, createdAt: new Date().toISOString(), archived: false });
  activeFilter = 'active'; saveNotes(); syncFilterButtons(); renderNotes(); showToast('Catatan berhasil disimpan.');
});
document.addEventListener('note:archive', ({ detail }) => {
  const note = notes.find((item) => item.id === detail.id);
  note.archived = !note.archived; saveNotes(); renderNotes(); showToast(note.archived ? 'Catatan dipindahkan ke arsip.' : 'Catatan dipulihkan.');
});
document.addEventListener('note:delete', ({ detail }) => {
  notes = notes.filter((note) => note.id !== detail.id); saveNotes(); renderNotes(); showToast('Catatan dihapus.');
});
document.querySelector('#search-input').addEventListener('input', (event) => { query = event.target.value.trim().toLowerCase(); renderNotes(); });
document.querySelectorAll('.filter-button').forEach((button) => button.addEventListener('click', () => { activeFilter = button.dataset.filter; syncFilterButtons(); renderNotes(); }));
function syncFilterButtons() { document.querySelectorAll('.filter-button').forEach((button) => button.classList.toggle('active', button.dataset.filter === activeFilter)); }

const today = new Date();
document.querySelector('#today-day').textContent = new Intl.DateTimeFormat('id-ID', { weekday: 'long' }).format(today);
document.querySelector('#today-date').textContent = new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long' }).format(today);
document.querySelector('#year').textContent = today.getFullYear();
renderNotes();
