# Ruang Catatan

Submission **Membangun Notes App** untuk kelas Belajar Fundamental Front-End Web Development.

## Menjalankan aplikasi

Buka `index.html` melalui browser. Tidak ada instalasi package dan tidak menggunakan framework JavaScript.

## Kriteria yang diterapkan

- Lima belas catatan awal dari data dummy resmi Dicoding ditampilkan tanpa perubahan.
- Formulir judul dan isi catatan.
- CSS Grid pada daftar catatan.
- Tiga custom element: `app-header`, `note-form`, dan `note-item`.
- Realtime validation pada formulir.
- Custom attribute: `app-name`, `owner`, `max-title`, dan `status`.
- Tampilan responsif untuk desktop, tablet, dan ponsel.
- Fitur tambahan: pencarian, arsip/pulihkan, hapus, penyimpanan localStorage, dan shortcut Ctrl + Enter.
